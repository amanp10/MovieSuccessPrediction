from sys import argv
import string

script,txt = argv

fi=open(txt)
st=fi.read()
fi.close()
st.replace('\n','')
list1=[]
list1=st.split(' ')
for filename in list1:
	filename=filename.replace('\n','')
	fi=open(filename)
	st=fi.read()
	i1=st.find('<title>')
	i2=st.find('</title>')
	title=st[i1+7:i2]
	i3=st.find('like this video along with ')
	i4=st.find(' other',i3)
	likes=st[i3+27:i4].replace(',','')
	i5=st.find('dislike this video along with ')
	i6=st.find(' other',i5)
	dislikes=st[i5+30:i6].replace(',','')
	if len(likes) <= 10:
		net=int(likes)-int(dislikes)
		if net < 0:
			net=0
		views=str(net)
	else:
		views='n/a'
	fi.close()
	if len(views) <= 10:
		fi=open('youtube.txt','a')
		fi.write(title+'\t'+views+'\n')
		fi.close()
