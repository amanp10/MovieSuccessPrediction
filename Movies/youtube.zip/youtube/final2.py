import string

fi=open('data.tsv')
fi.read()
i=fi.tell()
fi.seek(0)
list1=[]
while fi.tell() != i:
	list1.append(fi.readline().replace('\n',''))
print len(list1)
fi.close()

fi=open('youtube.tsv')
fi.read()
i=fi.tell()
fi.seek(0)
list2=[]
while fi.tell() != i:
	list2.append(fi.readline().replace('\n',''))
print len(list2)
fi.close()

list3=[]
for i in list1:
	appended=False
	split_data=i.split('\t')
	movie=split_data[1]
	for j in list2:
		split_data2=j.split('\t')
		if movie.lower() == split_data2[0].lower():
			z=i+split_data2[1]
			list3.append(z)
			appended=True
			break
	if appended == False:
		list3.append(i)

fi=open('final.tsv','w')
for i in list3:
	fi.write(i+'\n')
fi.close()

	

